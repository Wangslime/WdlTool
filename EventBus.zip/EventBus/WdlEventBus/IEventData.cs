﻿namespace WdlEventBus
{
    internal interface IEventData
    {

    }
}
